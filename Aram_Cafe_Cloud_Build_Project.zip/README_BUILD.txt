ARAM CAFE POS — ANDROID STUDIO PROJECT

This is a native Android WebView wrapper around the Aram Cafe POS starter app.
The menu, billing, inventory, PINs and reports are stored locally on this phone.
It works offline because the app's HTML is bundled inside the APK.

BUILD THE APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio (Open project).
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When complete, use the 'locate' link in Android Studio. The debug APK is normally:
   app/build/outputs/apk/debug/app-debug.apk
6. Transfer that APK to the Android phone and open it to install.
   If Android asks, allow installation from that file manager/browser.

FIRST LOGIN
Owner PIN: 2468
Cashier PIN: 1357
Change both PINs in Owner > Settings.

IMPORTANT
- This folder is the Android Studio source project, NOT a compiled APK.
- An Android SDK/Gradle build is required to produce the installable APK.
- Data is local to this phone; there is no cloud sync between owner/cashier phones yet.
- PIN separation is a starter-level local control, not production-grade server security.
- Keep regular backups using Owner > Settings > Export backup.
